package com.prashant.simpleimagesearch.Interfaces

import android.view.View

public interface OnItemClickListener {
    fun onItemClick(view: View?, position: Int)
}