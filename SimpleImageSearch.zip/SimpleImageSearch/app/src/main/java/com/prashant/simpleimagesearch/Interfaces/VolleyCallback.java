package com.prashant.simpleimagesearch.Interfaces;

public interface VolleyCallback {
    void onSuccessResponse(String result);
}
